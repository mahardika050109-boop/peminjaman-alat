<?php

session_start();

include "../../model/koneksi.php";

$id_alat = $_POST['id_alat'];
$id_kategori = $_POST['id_kategori'];
$nama_alat = $_POST['nama_alat'];
$stok = $_POST['stok'];
$kondisi_alat = $_POST['kondisi_alat'];

mysqli_query($conn,"
UPDATE tabel_alat
SET
id_kategori='$id_kategori',
nama_alat='$nama_alat',
stok='$stok',
kondisi_alat='$kondisi_alat'
WHERE id_alat='$id_alat'
");

$id_user = $_SESSION['id_user'];

mysqli_query($conn,"
INSERT INTO log_aktivitas
(
id_user,
aktivitas,
tanggal
)
VALUES
(
'$id_user',
'Mengubah data alat',
NOW()
)
");

header("Location:view_alat_tampil.php");
exit;

?>