<?php
include "../../model/koneksi.php";

$data = mysqli_query($conn,"
SELECT a.*,k.nama_kategori
FROM tabel_alat a
LEFT JOIN kategori k
ON a.id_kategori=k.id_kategori
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Daftar Alat</title>

<style>

body{
font-family:Arial;
background:#f0fdfa;
padding:15px;
}

.card{
background:white;
padding:15px;
border-radius:15px;
margin-bottom:10px;
box-shadow:0 3px 10px rgba(0,0,0,.08);
}

.kembali{
display:block;
margin-top:15px;
text-align:center;
text-decoration:none;
color:#0f766e;
font-weight:bold;
}

</style>

</head>
<body>

<h2>📦 Daftar Alat</h2>

<?php while($row=mysqli_fetch_array($data)){ ?>

<div class="card">

<b><?= $row['nama_alat']; ?></b><br>

Kategori :
<?= $row['nama_kategori']; ?><br>

Stok :
<?= $row['stok']; ?><br>

Kondisi :
<?= $row['kondisi_alat']; ?>

</div>

<?php } ?>

<a href="../../dashboard_peminjam.php" class="kembali">
← Kembali ke Dashboard
</a>

</body>
</html>