<?php

session_start();

include "../../model/koneksi.php";

$id_kategori = $_POST['id_kategori'];
$nama_alat = $_POST['nama_alat'];
$stok = $_POST['stok'];
$kondisi_alat = $_POST['kondisi_alat'];

mysqli_query($conn,"
INSERT INTO tabel_alat
(
id_kategori,
nama_alat,
stok,
kondisi_alat
)
VALUES
(
'$id_kategori',
'$nama_alat',
'$stok',
'$kondisi_alat'
)
");

$id_user = $_SESSION['id_user'];

mysqli_query($conn,"
INSERT INTO log_aktivitas
(
id_user,
aktivitas,
tanggal
)
VALUES
(
'$id_user',
'Menambah data alat',
NOW()
)
");

header("Location:view_alat_tampil.php");
exit;

?>