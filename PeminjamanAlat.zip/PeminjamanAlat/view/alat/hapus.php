<?php

session_start();

include "../../model/koneksi.php";

$id = $_GET['id'];

mysqli_query($conn,"
DELETE FROM tabel_alat
WHERE id_alat='$id'
");

$id_user = $_SESSION['id_user'];

mysqli_query($conn,"
INSERT INTO log_aktivitas
(
id_user,
aktivitas,
tanggal
)
VALUES
(
'$id_user',
'Menghapus data alat',
NOW()
)
");

header("Location:view_alat_tampil.php");
exit;

?>