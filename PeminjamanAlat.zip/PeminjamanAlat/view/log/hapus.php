<?php

include "../../model/koneksi.php";

$id = $_GET['id'];

mysqli_query($conn,"
DELETE FROM log_aktivitas
WHERE id_log='$id'
");

header("Location:view_log_tampil.php");
exit;

?>