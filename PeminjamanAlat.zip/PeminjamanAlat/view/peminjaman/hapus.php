<?php

session_start();
include "../../model/koneksi.php";

$id = $_GET['id'];

mysqli_query($conn,"
DELETE FROM peminjaman
WHERE id_peminjaman='$id'
");

$id_login = $_SESSION['id_user'];

mysqli_query($conn,"
INSERT INTO log_aktivitas
(
id_user,
aktivitas,
tanggal
)
VALUES
(
'$id_login',
'Menghapus data peminjaman',
NOW()
)
");

header("Location:view_peminjaman_tampil.php");
exit;

?>