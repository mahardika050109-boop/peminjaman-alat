<?php

session_start();
include "../../model/koneksi.php";

$id = $_POST['id_peminjaman'];
$tanggal_pinjam = $_POST['tanggal_pinjam'];
$tanggal_kembali = $_POST['tanggal_kembali'];
$status = $_POST['status'];

mysqli_query($conn,"
UPDATE peminjaman
SET
tanggal_pinjam='$tanggal_pinjam',
tanggal_kembali='$tanggal_kembali',
status='$status'
WHERE id_peminjaman='$id'
");

$id_login = $_SESSION['id_user'];

mysqli_query($conn,"
INSERT INTO log_aktivitas
(
id_user,
aktivitas,
tanggal
)
VALUES
(
'$id_login',
'Mengubah data peminjaman',
NOW()
)
");

header("Location:view_peminjaman_tampil.php");
exit;

?>