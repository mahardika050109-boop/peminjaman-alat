<?php

session_start();
include "../../model/koneksi.php";

$id_user          = $_POST['id_user'];
$id_alat          = $_POST['id_alat'];
$jumlah           = $_POST['jumlah'];
$tanggal_pinjam   = $_POST['tanggal_pinjam'];
$tanggal_kembali  = $_POST['tanggal_kembali'];
$status           = $_POST['status'];

mysqli_query($conn,"
INSERT INTO peminjaman
(
id_user,
tanggal_pinjam,
tanggal_kembali,
status
)
VALUES
(
'$id_user',
'$tanggal_pinjam',
'$tanggal_kembali',
'$status'
)
");

$id_peminjaman = mysqli_insert_id($conn);

mysqli_query($conn,"
INSERT INTO detail_peminjaman
(
id_peminjaman,
id_alat,
jumlah
)
VALUES
(
'$id_peminjaman',
'$id_alat',
'$jumlah'
)
");

$id_login = $_SESSION['id_user'];

mysqli_query($conn,"
INSERT INTO log_aktivitas
(
id_user,
aktivitas,
tanggal
)
VALUES
(
'$id_login',
'Menambah data peminjaman',
NOW()
)
");

header("Location:view_peminjaman_tampil.php");
exit;

?>