<?php
session_start();
include "../../model/koneksi.php";

$id_peminjam = $_POST['id_peminjam'];
$tanggal_pengembalian = $_POST['tanggal_pengembalian'];
$kondisi_pengembalian = $_POST['kondisi_pengembalian'];
$status = $_POST['status'];
$denda = $_POST['denda'];

mysqli_query($conn,"
INSERT INTO tabel_pengembalian
(
id_peminjam,
tanggal_pengembalian,
kondisi_pengembalian,
status,
denda
)
VALUES
(
'$id_peminjam',
'$tanggal_pengembalian',
'$kondisi_pengembalian',
'$status',
'$denda'
)
");

mysqli_query($conn,"
UPDATE peminjaman
SET status='Dikembalikan'
WHERE id_peminjaman='$id_peminjam'
");

if(isset($_SESSION['id_user'])){

mysqli_query($conn,"
INSERT INTO log_aktivitas
(
id_user,
aktivitas,
tanggal
)
VALUES
(
'".$_SESSION['id_user']."',
'Menambah data pengembalian',
NOW()
)
");

}

header("Location:view_pengembalian_tampil.php");
exit;
?>