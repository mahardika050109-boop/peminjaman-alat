<?php

session_start();

include "../../model/koneksi.php";

$id = $_POST['id_pengembalian'];
$tanggal_pengembalian = $_POST['tanggal_pengembalian'];
$kondisi_pengembalian = $_POST['kondisi_pengembalian'];
$status = $_POST['status'];
$denda = $_POST['denda'];

mysqli_query($conn,"
UPDATE tabel_pengembalian
SET
tanggal_pengembalian='$tanggal_pengembalian',
kondisi_pengembalian='$kondisi_pengembalian',
status='$status',
denda='$denda'
WHERE id_pengembalian='$id'
");

$id_user = $_SESSION['id_user'];

mysqli_query($conn,"
INSERT INTO log_aktivitas
(
id_user,
aktivitas,
tanggal
)
VALUES
(
'$id_user',
'Mengubah data pengembalian',
NOW()
)
");

header("Location:view_pengembalian_tampil.php");
exit;

?>