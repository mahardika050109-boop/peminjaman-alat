<?php

session_start();

include "../../model/koneksi.php";

$id_kategori = $_POST['id_kategori'];
$nama_kategori = $_POST['nama_kategori'];
$keterangan = $_POST['keterangan'];
$status = $_POST['status'];

mysqli_query($conn,"
UPDATE kategori
SET
nama_kategori='$nama_kategori',
keterangan='$keterangan',
status='$status'
WHERE id_kategori='$id_kategori'
");

$id_user = $_SESSION['id_user'];

mysqli_query($conn,"
INSERT INTO log_aktivitas
(
id_user,
aktivitas,
tanggal
)
VALUES
(
'$id_user',
'Mengubah kategori',
NOW()
)
");

header("Location:view_kategori_tampil.php");
exit;

?>