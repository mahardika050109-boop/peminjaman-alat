<?php

session_start();

include "../../model/koneksi.php";

$nama_kategori = $_POST['nama_kategori'];
$keterangan = $_POST['keterangan'];
$status = $_POST['status'];

mysqli_query($conn,"
INSERT INTO kategori
(
nama_kategori,
keterangan,
status
)
VALUES
(
'$nama_kategori',
'$keterangan',
'$status'
)
");

$id_user = $_SESSION['id_user'];

mysqli_query($conn,"
INSERT INTO log_aktivitas
(
id_user,
aktivitas,
tanggal
)
VALUES
(
'$id_user',
'Menambah kategori',
NOW()
)
");

header("Location:view_kategori_tampil.php");
exit;

?>