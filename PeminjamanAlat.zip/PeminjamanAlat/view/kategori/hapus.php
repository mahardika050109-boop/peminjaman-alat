<?php

session_start();

include "../../model/koneksi.php";

$id = $_GET['id'];

mysqli_query($conn,"
DELETE FROM kategori
WHERE id_kategori='$id'
");

$id_user = $_SESSION['id_user'];

mysqli_query($conn,"
INSERT INTO log_aktivitas
(
id_user,
aktivitas,
tanggal
)
VALUES
(
'$id_user',
'Menghapus kategori',
NOW()
)
");

header("Location:view_kategori_tampil.php");
exit;

?>